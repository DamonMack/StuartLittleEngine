var searchData=
[
  ['zoom_0',['zoom',['../class_camera.html#a21fc9e142b104d8e94126657abaa075f',1,'Camera']]]
];
